function Title() {
  return <h2>See it in action</h2>;
}

export default Title;
